package org.nju.jlxy.pet;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UserService {

    private mSQLiteOpenHelper dbHelper;

    public UserService(Context context) {
        dbHelper = new mSQLiteOpenHelper(context);
    }

    public boolean login(String account, String password) {
        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        String sql = "select * from user where account=? and password=?";
        Cursor cursor = sdb.rawQuery(sql, new String[]{account, password});
        if (cursor.moveToFirst() == true) {
            cursor.close();
            return true;
        }
        return false;
    }

    public boolean register(User user) {
        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        try{
            String sql = "insert into user(account,password) values(?,?)";
            Object obj[] = {user.getAccount(), user.getPasswd()};
            sdb.execSQL(sql, obj);
        }catch (Exception e){
            return false;
        }
        return true;
    }

    public ArrayList<Map<String, String>> show(User user) {
        ArrayList<Map<String, String>> list = new ArrayList<>();

        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        String sql = "select * from user where account=?";
        Cursor cursor = sdb.rawQuery(sql, new String[]{user.getAccount()});

        while(cursor.moveToNext()){
            HashMap<String, String> map = new HashMap<>();
            map.put("name", cursor.getString(cursor.getColumnIndex("name")));
            map.put("email", cursor.getString(cursor.getColumnIndex("email")));
            map.put("tele", cursor.getString(cursor.getColumnIndex("tele")));
            map.put("gender", cursor.getString(cursor.getColumnIndex("gender")));
            list.add(map);
        }

        return list;
    }

}
