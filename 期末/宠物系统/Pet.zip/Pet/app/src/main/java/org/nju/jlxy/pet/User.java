package org.nju.jlxy.pet;

public class User {

    private String account;
    private String passwd;
    private String uid;

    private String email;
    private String tele;
    private String gender;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public User(String account, String passwd) {
        this.account = account;
        this.passwd = passwd;
    }



    public String getAccount() {
        return account;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTele(String tele) {
        this.tele = tele;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public String getTele() {
        return tele;
    }

    public String getGender() {
        return gender;
    }
}
