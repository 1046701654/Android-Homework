package org.nju.jlxy.pet;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BlogAdapter extends RecyclerView.Adapter<BlogAdapter.MyViewHolder> {

    private List<Blog> blogs;

    public BlogAdapter(List<Blog> blogs) {
        this.blogs = blogs;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.context, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Blog blog = blogs.get(position);

        holder.user_image.setImageResource(R.mipmap.userimage);
        holder.user_name.setText(blog.getUsername());
        holder.user_context.setText(blog.getContext());
        for (int i = 0; i < holder.user_pictures.length; i++) {
            holder.user_pictures[i].setImageResource(R.mipmap.test1);
        }
//        holder.user_share.setText();
//        holder.user_comment.setText();
//        holder.user_like.setText();
    }

    @Override
    public int getItemCount() {
        return blogs.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView user_image;
        TextView user_name;
        TextView user_context;
        ImageView[] user_pictures;
        TextView user_share;
        TextView user_comment;
        TextView user_like;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            user_image = itemView.findViewById(R.id.context_user_image);
            user_name = itemView.findViewById(R.id.context_user_name);
            user_context = itemView.findViewById(R.id.context_user_context);
            user_pictures = new ImageView[3];
            user_pictures[0] = itemView.findViewById(R.id.context_user_image1);
            user_pictures[1] = itemView.findViewById(R.id.context_user_image2);
            user_pictures[2] = itemView.findViewById(R.id.context_user_image3);
            user_share = itemView.findViewById(R.id.context_share);
            user_comment = itemView.findViewById(R.id.context_comment);
            user_like = itemView.findViewById(R.id.context_like);
        }
    }
}
