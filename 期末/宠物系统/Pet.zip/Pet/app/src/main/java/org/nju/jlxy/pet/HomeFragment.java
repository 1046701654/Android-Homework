package org.nju.jlxy.pet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ListView list;
    private List<Blog> blogs;
    private RecyclerView recyclerView;

    public HomeFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recycle_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        initBlogs();
        for (int i = 0; i < 10; i++) {
//            new BlogService(getContext()).fakePublish(i);
            blogs.add(getBlog(i));
        }
        BlogAdapter blogAdapter = new BlogAdapter(blogs);
        recyclerView.setAdapter(blogAdapter);

        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));

        return view;
    }

    public Blog getBlog(int bid){

        BlogService blogService = new BlogService(getContext());

        Blog blog = blogService.getContext(bid);
        return blog;
    }

    public void initBlogs(){
        blogs = new ArrayList<Blog>();
    }

}
