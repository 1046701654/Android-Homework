package org.nju.jlxy.pet;

import android.media.Image;
import android.widget.ImageView;

public class Blog {

    private String bid;
    private String username;
    private String postTime;
    private String context;

    public Blog(String bid, String username, String postTime, String context) {
        this.bid = bid;
        this.username = username;
        this.postTime = postTime;
        this.context = context;
    }

    public Blog(String username, String context){
        this.username = username;
        this.context  = context;
    }

    public String getUid() {
        return bid;
    }

    public void setUid(String uid) {
        this.bid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPostTime() {
        return postTime;
    }

    public void setPostTime(String postTime) {
        this.postTime = postTime;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }
}
