package org.nju.jlxy.pet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private Button confirm;

    private EditText ed_account;
    private EditText ed_passwd;
    private EditText ed_email;
    private EditText ed_tele;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        confirm = findViewById(R.id.register);

        ed_account = findViewById(R.id.ed_account);
        ed_passwd = findViewById(R.id.ed_passwd);

        confirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                UserService userService = new UserService(SignupActivity.this);
                String account = ed_account.getText().toString();
                String passwd  = ed_passwd.getText().toString();

                User user = new User(account, passwd);

                if (!userService.register(user)){
                    Toast.makeText(SignupActivity.this, "register error", Toast.LENGTH_SHORT);
                }
                else{
                    Intent intent = new Intent(SignupActivity.this, LoginActivity.class);

                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
