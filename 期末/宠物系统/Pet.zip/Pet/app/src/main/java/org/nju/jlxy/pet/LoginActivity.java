package org.nju.jlxy.pet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private Button bt_signup;
    private Button bt_login;

    private EditText login_account;
    private EditText login_passwd;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        bt_signup = findViewById(R.id.btn_signup);
        bt_login = findViewById(R.id.btn_login);

        login_account = findViewById(R.id.login_account);
        login_passwd = findViewById(R.id.login_passwd);


        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UserService userService = new UserService(LoginActivity.this);

                String account = login_account.getText().toString();
                String passwd = login_passwd.getText().toString();

                if (userService.login(account, passwd)){
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                    startActivity(intent);
                    finish();
                }
                else{
                    Toast.makeText(LoginActivity.this, "Login error.",
                            Toast.LENGTH_SHORT).show();//事件触发,显示登录失败
                }
            }
        });

        bt_signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);

                startActivity(intent);
                finish();
            }
        });
    }


}
