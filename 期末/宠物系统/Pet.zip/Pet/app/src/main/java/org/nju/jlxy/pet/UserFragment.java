package org.nju.jlxy.pet;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Map;

public class UserFragment extends Fragment {

    private TextView tv_username;
    private TextView tv_useremail;
    private TextView tv_usertele;
    private TextView tv_usergender;

    private ImageView iv_user;

    public UserFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        iv_user = view.findViewById(R.id.iv_user);
//        iv_user.bringToFront();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_users, container, false);

        tv_username = view.findViewById(R.id.tv_user_name);
        tv_useremail = view.findViewById(R.id.tv_user_email);
        tv_usertele = view.findViewById(R.id.tv_user_tele);
        tv_usergender = view.findViewById(R.id.tv_user_gender);

        UserService userService = new UserService(getContext());

        return view;
    }
}
