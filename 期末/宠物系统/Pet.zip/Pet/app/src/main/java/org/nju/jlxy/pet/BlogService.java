package org.nju.jlxy.pet;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BlogService {

    private mSQLiteOpenHelper dbHelper;

    public BlogService(Context context) {
        this.dbHelper = new mSQLiteOpenHelper(context);
    }

    public boolean publish(Blog blog) {
        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        String sql = "insert into blog(username, context)values(?, ?)";
        Object obj[] = {blog.getUsername(), blog.getContext()};
        sdb.execSQL(sql, obj);
        return true;
    }

    public Blog getContext(int bid){
        Blog blog = null;

        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        String sql = "select * from blog where bid=?";
        Cursor cursor = sdb.rawQuery(sql, new String[]{(bid+1) + ""});
        if (cursor.moveToFirst() == true) {
            String username = cursor.getString(cursor.getColumnIndex("username"));
            String context  = cursor.getString(cursor.getColumnIndex("context"));

            blog = new Blog(username, context);
            cursor.close();
        }
        return blog;
    }

    public void fakePublish(int id){
        SQLiteDatabase sdb = dbHelper.getReadableDatabase();
        String sql = "insert into blog(username,context)values(?,?)";
        Object obj[] = {"user" + id, "This is test context, you will see some short sentence." + id};
        sdb.execSQL(sql, obj);
    }
}
