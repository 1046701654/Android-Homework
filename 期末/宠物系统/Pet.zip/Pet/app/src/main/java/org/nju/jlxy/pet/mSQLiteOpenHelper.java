package org.nju.jlxy.pet;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class mSQLiteOpenHelper extends SQLiteOpenHelper {
    static String name = "user.db";
    static int dbVersion = 1;

    public mSQLiteOpenHelper(Context context) {
        super(context, name, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table user(" +
                "id integer primary key autoincrement," +
                "account varchar(20) unique," +
                "password varchar(20)," +
                "email varchar(50)," +
                "tele varchar(20)," +
                "gender varchar(20));";
        db.execSQL(sql);

        sql = "create table blog(" +
                "bid integer primary key autoincrement," +
                "username varchar(20) unique not null," +
                "context text not null," +
                "publishtime datatime default current_timestamp);";
        db.execSQL(sql);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists blog");
        onCreate(db);
    }
}
